import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Link from '@mui/material/Link';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import {useContext, useEffect, useState} from "react";
import {Snackbar, Stack} from "@mui/material";
import MuiAlert from '@mui/material/Alert';
import {AuthContext} from "../../../context/Authcontext";
import "../../Login/style/index.css";

function Copyright(props) {
    return (
        <Typography variant="body2" color="text.secondary" align="center" {...props}>
            {'Copyright © '}
            <Link color="inherit" href="https://excelegal.in/">
                Excelegal
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

const theme = createTheme();

const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});


export default function SignUpPage() {
    const {loggedIn} = useContext(AuthContext);

    useEffect(()=> {
        if (loggedIn) {
            window.location.pathname = "courses";
        }
    },[]);

    const handleSubmit = (event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
    };


    const [email, setEmail] = useState('');
    const [firstname, setFirstName] = useState('');
    const [lastname, setLastName] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const [open, setOpen] = useState(false);
    const [loginError, setLoginError] = useState('');

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpen(false);
    };

    const snackbar = () =>{
        return (
            <Stack spacing={2} sx={{ width: '100%' }}>
                <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                    <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
                        {loginError}
                    </Alert>
                </Snackbar>
            </Stack>
        );
    }


    const signUp= () => {
        if(confirmPassword!==password){
            setOpen(true);
            setLoginError("Both Password Don't Match");
        }
        else{
            fetch(`${process.env.REACT_APP_BASE_URL}/auth/signup/`, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ "email": email, "password": password, "firstname": firstname
                , "lastname": lastname})
            })
                .then((res) => {
                    if(!res.ok){
                        const err = new Error("Error");
                        err.response = res;
                        throw err.responseforgotpassword.json();
                    }
                    return res.json();
                })
                .then(()=> window.location.pathname= "/email-verify")
                .catch((err)=>{
                    setOpen(true);
                    err.then((data)=> {
                        if(data.payload && data.payload.password){
                            setLoginError(data.payload.password);
                        }else{
                            if(data.payload && data.payload.email){
                                setLoginError(data.payload.email);
                            }else{
                                setLoginError(data.message);
                            }
                        }

                    });
                });
        }
    }


    return (
        <div className="loginPage">

            <div className="formFields">
                {/*<img src={require("../../../images/contest.webp")} alt="" className="excelegalLogo"/>*/}
                <div className="formHeading">
                    Excelegal
                </div>

                {/*<Container component="main" maxWidth="xs">*/}
                <input className="inputLogin" type="text" id="email" name="email" placeholder="Email" onChange={(e)=> setEmail(e.target.value)} />
                <input className="inputLogin" type="password" id="password" name="password" placeholder="Password" onChange={(e)=> setPassword(e.target.value)} />
                <input className="inputLogin" type="password" id="confirm-password" name="confirm-password" placeholder="Confirm Password" onChange={(e)=> setConfirmPassword(e.target.value)} />
                <input className="inputLogin" type="text" id="firstname" name="firstname" placeholder="First Name" onChange={(e)=> setFirstName(e.target.value)} />
                <input className="inputLogin" type="text" id="lastname" name="lastname" placeholder="Last Name" onChange={(e)=> setLastName(e.target.value)} />

                <button
                    className="submitButton"
                    type="submit"
                    onClick={signUp}
                >
                    Sign In
                </button>
                <div className="forgetAndSignup"  onClick={()=> window.location.pathname="login"}>
                    Login
                </div>
            </div>

            {snackbar()}
        </div>
    );
}