import {useCallback} from "react";
import { GoogleLogin } from 'react-google-login';
const { REACT_APP_GOOGLE_CLIENT_ID } = process.env;

function GoogleLoginPage() {

    // const REACT_APP_BACKEND_URL=`http://localhost:8000/auth/login/google/`
    const REACT_APP_BACKEND_URL=`${process.env.REACT_APP_BASE_URL}/auth/login/google/`

    const openGoogleLoginPage = useCallback(() => {
        const googleAuthUrl = 'https://accounts.google.com/o/oauth2/v2/auth';
        const redirectUri = 'api/v1/auth/login/google/';

        const scope = [
            'https://www.googleapis.com/auth/userinfo.email',
            'https://www.googleapis.com/auth/userinfo.profile'
        ].join(' ');

        const params = {
            response_type: 'code',
            client_id: `${REACT_APP_GOOGLE_CLIENT_ID}`,
            redirect_uri: `${REACT_APP_BACKEND_URL}`,
            prompt: 'select_account',
            access_type: 'offline',
            scope
        };
        debugger
        const urlParams = new URLSearchParams(params).toString();

        window.location = `${googleAuthUrl}?${urlParams}`;
    }, []);


    return (
        <div className="App">
            {/*<button*/}
            {/*    onClick={openGoogleLoginPage}*/}
            {/*>*/}
            {/*    Sign in with Google*/}
            {/*</button>*/}
        </div>
    );
}

export default GoogleLoginPage;