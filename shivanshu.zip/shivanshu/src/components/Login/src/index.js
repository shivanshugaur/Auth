import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import {useContext, useEffect, useState} from "react";
import MuiAlert from "@mui/material/Alert";
import {Snackbar, Stack} from "@mui/material";
import { styled } from '@mui/material/styles';
import {AuthContext} from "../../../context/Authcontext";
import GoogleLoginPage from "../common/GoogleSignIn";
import "../style/index.css";
import {lime} from "@mui/material/colors";

const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function LoginPage() {

    const {loggedIn} = useContext(AuthContext);

    useEffect(()=> {
        if (loggedIn) {
            window.location.pathname = "courses";
        }
    },[]);


    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const [open, setOpen] = useState(false);

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpen(false);
    };

    const [loginError, setLoginError] = useState('');

    const snackbar = () =>{
        return (
            <Stack spacing={2} sx={{ width: '100%' }}>
                <Snackbar open={open} autoHideDuration={2000} onClose={handleClose}>
                    <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
                        {loginError}
                    </Alert>
                </Snackbar>
            </Stack>
        );
    }


    const loginUser=()=>{
        fetch(`${process.env.REACT_APP_BASE_URL}/auth/token/`, {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: email, password: password })
        })
            .then((res) => {
                if(!res.ok){
                    const err = new Error("Error");
                    err.response = res;
                    throw err.response.json();
                }
                return res.json();
            })
            .then((data)=> {
                localStorage.setItem("authtoken", data.payload.access);
            })
            .then(()=> window.location.pathname= "/")
            .catch((err)=>{
                setOpen(true);
                err.then((data)=> {
                    setLoginError(data.message);
                });
            });
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
    };

    const CssTextField = styled(TextField)({
        '& label.Mui-focused': {
            color: 'black',
        },
        '& .MuiInput-underline:after': {
            borderBottomColor: 'black',
        },
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                borderColor: 'black',
            },
            '&:hover fieldset': {
                borderColor: 'black',
            },
            '&.Mui-focused fieldset': {
                borderColor: 'white',
            },
        },
    });


    return (
        <div className="loginPage">
            <div className="formFields">
                {/*<form className="formGG">*/}

                {/*<img src={require("../../../images/contest.webp")} alt="" className="excelegalLogo"/>*/}
                <div className="formHeading">
                    Excelegal
                </div>

            {/*<Container component="main" maxWidth="xs">*/}
                    <input className="inputLogin" type="text" id="email" name="email" placeholder="Email" onChange={(e)=> setEmail(e.target.value)} />
                    <input className="inputLogin" type="password" id="password" name="password" placeholder="Password" onChange={(e)=> setPassword(e.target.value)} />

                    <button
                        className="submitButton"
                        type="submit"
                        onClick={loginUser}
                    >
                        Sign In
                    </button>
                {/*</form>*/}
                <div className="forgetAndSignup inputFields"  onClick={()=> window.location.pathname="forgotpassword"}>
                    Forgot Password
                </div>
                <div className="forgetAndSignup"  onClick={()=> window.location.pathname="signup"}>
                    Don't have account? Sign Up
                </div>
            </div>

        {snackbar()}
        </div>
    );
}