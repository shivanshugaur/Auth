import { Route, Routes, Navigate, useLocation } from 'react-router-dom';
import { BrowserRouter } from 'react-router-dom';
import HomePage from './components/HomePage/src';
import LoginPage from "./components/Login/src";
import AddCourseTopicFormComponent from './components/AdminPanelComponent/common/AddCourseTopicFormComponent';
import AddCourseFormComponent from './components/AdminPanelComponent/common/AddCourseFormComponent';
import BlogPageComponent from './components/AdminPanelComponent/common/BlogPageComponent';
import AddBlogFormComponent from './components/AdminPanelComponent/common/AddBlogFormComponent';
import CoursesPageComponent from './components/AdminPanelComponent/common/CoursesPageComponent';
import CourseTopicPageComponent from './components/AdminPanelComponent/common/CourseTopicPageComponent';
import SignUpPage from './components/SignUp/src';
import ResponsiveAppBar from './components/NavBarComponent/src';
import { AuthContext } from "./context/Authcontext";
import { useContext } from "react";
import FooterExcelegal from './components/FooterExcelegal/src';
import './App.css';
import ForgotPassword from "./components/ForgotPassword";
import ResetPassword from "./components/ForgotPassword/ResetPass";
import BulletinComponent from "./components/AdminPanelComponent/common/Bulletin";
import AddBulletinFormComponent from "./components/AdminPanelComponent/common/Bulletin/AddBulletin";
import VerifyEmail from "./components/AdminPanelComponent/common/VerifyEmail";
import VerifyPassword from "./components/AdminPanelComponent/common/Verify-Password";
import QuizPageComponent from './components/AdminPanelComponent/common/QuizPageComponent';
import AddQuizFormComponent from './components/AdminPanelComponent/common/AddQuizFormComponent';
import AddQuizQuestionFormComponent from './components/AdminPanelComponent/common/AddQuizQuestionComponent';
import QuizQuestionsPageComponent from './components/AdminPanelComponent/common/QuizQuestionsPageComponent';
import InternshipPageComponent from "./components/AdminPanelComponent/common/InternshipPageComponent";
import AddInternshipFormComponent from "./components/AdminPanelComponent/common/AddInternshipFormComponent";
import CourseInternshipPageComponent from "./components/AdminPanelComponent/common/InternshipTopicPageComponent";
// import InternshipTopicPageComponent from "./components/AdminPanelComponent/common/InternshipTopicPageComponent";

function App() {
  function AuthenticatedRoute({ children }) {
    const { loggedIn } = useContext(AuthContext);
    let location = useLocation();
    if (!loggedIn) {
      return <Navigate to="/login" state={{ from: location }} replace />;
    }
    return children;
  }


  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/" element={
            <>
            <ResponsiveAppBar />
             <HomePage />
            <FooterExcelegal />
            </>
        } />
        {/*<Route exact path="/admin/courses" element={<CoursesPageComponent />} />*/}
        <Route exact path="/forgotpassword" element={<ForgotPassword />} />
        <Route exact path="/forgot-password" element={<ResetPassword />} />
        <Route exact path="/email-forget-page" element={<VerifyPassword />} />
        <Route exact path="/signup" element={<SignUpPage />} />
        {/*<Route exact path="/verify-email" element={<VerifyEmail />} />*/}
        <Route exact path="/email-verify" element={<VerifyEmail />} />
        {/*<Route exact path="/verify-email" element={<VerifyEmail />} />*/}
        <Route exact path="/login" element={<LoginPage />} />
        <Route
          path="/courses"
          element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
              <CoursesPageComponent />
            </AuthenticatedRoute>
          }
        />

        <Route exact path="/addcourse" element={
          <AuthenticatedRoute >
              <ResponsiveAppBar />
            <AddCourseFormComponent />
          </AuthenticatedRoute>} />
        <Route exact path="/courses" element={
          <AuthenticatedRoute >
              <ResponsiveAppBar />
              <CoursesPageComponent />
              <FooterExcelegal />
          <FooterExcelegal />
          </AuthenticatedRoute>} />
        <Route exact path="/courses/:courseSlug" element={
          <AuthenticatedRoute >
              <ResponsiveAppBar />
            <CourseTopicPageComponent />
          <FooterExcelegal />
          </AuthenticatedRoute>} />
        <Route exact path="/courses/:courseSlug/addcoursetopic" element={
          <AuthenticatedRoute >
              <ResponsiveAppBar />
            <AddCourseTopicFormComponent />
          <FooterExcelegal />
          </AuthenticatedRoute>} />
        <Route exact path="/courses/:courseSlug/topic/:topicSlug" element={
          <AuthenticatedRoute >
              <ResponsiveAppBar />
            <AddCourseTopicFormComponent isUpdate={true} />
          <FooterExcelegal />
          </AuthenticatedRoute>} />

        <Route exact path="/addblog" element={
          <AuthenticatedRoute >
              <ResponsiveAppBar />
            <AddBlogFormComponent />
          <FooterExcelegal />
          </AuthenticatedRoute>} />
        <Route exact path="/blogs" element={
          <AuthenticatedRoute >
              <ResponsiveAppBar />
            <BlogPageComponent />
          <FooterExcelegal />
          </AuthenticatedRoute>} />
        <Route exact path="/blogs/:blogSlug" element={
          <AuthenticatedRoute >
              <ResponsiveAppBar />
            <AddBlogFormComponent isUpdate={true} />
          <FooterExcelegal />
          </AuthenticatedRoute>} />

        <Route
          path="/bulletin"
          element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
              <BulletinComponent />
            <FooterExcelegal />
            </AuthenticatedRoute>
          }
        />
        <Route
          path="/bulletin/:bulletinSlug"
          element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
              <AddBulletinFormComponent isUpdate={true} />
            <FooterExcelegal />
            </AuthenticatedRoute>
          }
        />
        <Route
          path="/add_bulletin"
          element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
              <AddBulletinFormComponent />
            <FooterExcelegal />
            </AuthenticatedRoute>
          }
        />

        {/*<Route*/}
        {/*    path="/internship"*/}
        {/*    element={*/}
        {/*      <AuthenticatedRoute >*/}
        {/*          <ResponsiveAppBar />*/}
        {/*        <InternshipPageComponent />*/}
        {/*      <FooterExcelegal />*/}
        {/*      </AuthenticatedRoute>*/}
        {/*    }*/}
        {/*/>*/}
        {/*<Route*/}
        {/*    path="/internship/:internshipSlug"*/}
        {/*    element={*/}
        {/*      <AuthenticatedRoute >*/}
        {/*          <ResponsiveAppBar />*/}
        {/*        <InternshipTopicPageComponent />*/}
        {/*      <FooterExcelegal />*/}
        {/*      </AuthenticatedRoute>*/}
        {/*    }*/}
        {/*/>*/}
        {/*<Route*/}
        {/*    path="/addInternship"*/}
        {/*    element={*/}
        {/*      <AuthenticatedRoute >*/}
        {/*          <ResponsiveAppBar />*/}
        {/*        <AddInternshipFormComponent />*/}
        {/*      <FooterExcelegal />*/}
        {/*      </AuthenticatedRoute>*/}
        {/*    }*/}
        {/*/>*/}
        {/*<Route*/}
        {/*    path="/add_bulletin"*/}
        {/*    element={*/}
        {/*      <AuthenticatedRoute >
        <ResponsiveAppBar />*/}
        {/*        <AddBulletinFormComponent />*/}
        {/*      </AuthenticatedRoute>*/}
        {/*    }*/}
        {/*/>*/}


        <Route exact path="/quiz" element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
                    <QuizPageComponent />
                <FooterExcelegal />
            </AuthenticatedRoute>} />
        <Route exact path="/quiz/addquiz" element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
                <AddQuizFormComponent />
                <FooterExcelegal />
            </AuthenticatedRoute>} />
        <Route exact path="/quiz/:quizId" element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
                <AddQuizFormComponent isUpdate={true} />
                <FooterExcelegal />
            </AuthenticatedRoute>} />
        <Route exact path="/quiz/addquestion" element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
                <AddQuizQuestionFormComponent />
                <FooterExcelegal />
            </AuthenticatedRoute>} />
        <Route exact path="/quiz/allquestions" element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
                <QuizQuestionsPageComponent />
                <FooterExcelegal />
            </AuthenticatedRoute>} />
        <Route exact path="/quiz/allquestions/:questionId" element={
            <AuthenticatedRoute >
                <ResponsiveAppBar />
                <AddQuizQuestionFormComponent isUpdate={true} />
                <FooterExcelegal />
            </AuthenticatedRoute>} />

        <Route exact path="*" element={<Navigate to="/" />} />
      </Routes>
      {/*<FooterExcelegal />*/}
    </BrowserRouter >
  );
}

export default App;
